package imc.unp.com.acelerometro;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    TextView txtEixoX, txtEixoY, txtEixoZ, txtPosicao;
    SensorManager sensorManager;
    Sensor sensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtEixoX = (TextView) findViewById(R.id.txtEixoX);
        txtEixoY = (TextView) findViewById(R.id.txtEixoY);
        txtEixoZ = (TextView) findViewById(R.id.txtEixoZ);
        txtPosicao = (TextView) findViewById(R.id.txtPosicao);

        //Instanciar classes
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        //Definir qual tipo de sensor a ser usado
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Float x = event.values[0];
        Float y = event.values[1];
        Float z = event.values[2];

        txtEixoX.setText("Valor eixo X: " + x.intValue());
        txtEixoY.setText("Valor eixo Y: " + y.intValue());
        txtEixoZ.setText("Valor eixo Z: " + z.intValue());

        if(y < 0) {
            txtPosicao.setText(x > 0 ? "Esquerda\nInvertido" : "Direita\nInvertido");
        } else {
            txtPosicao.setText(x > 0 ? "Esquerda" : "Direita");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}

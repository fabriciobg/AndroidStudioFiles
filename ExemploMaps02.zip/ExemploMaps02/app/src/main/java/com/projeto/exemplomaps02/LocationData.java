package com.projeto.exemplomaps02;

public class LocationData {
    double latitude;
    double longitude;

    public LocationData(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
}

package com.projeto.bluetooth;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothDevice bluetoothDevice = null;
    BluetoothAdapter bluetoothAdapter = null;
    BluetoothSocket mySockets = null;
    public UUID myUUID;
    Button btnConectar, btnPareados;
    Switch swBT;
    ImageView imgBT;
    ListView lstBT;
    public ArrayAdapter<String> lstAdapter;
    public ArrayList<String> dadosBT;
    String[] end_mac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myUUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"); // Bluetooth via serial port
//        myUUID = UUID.fromString("00000003-0000-1000-8000-00805f9b34fb"); // Bluetooth via serial COMM

        btnConectar = findViewById(R.id.btnConectar);
        btnPareados = findViewById(R.id.btnPareados);
        swBT = findViewById(R.id.swBT);
        imgBT = findViewById(R.id.imgBT);
        lstBT = findViewById(R.id.lstBT);

        // Criando a instancia do adaptador bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        // Verificar se Bluetooth está acessível
        if(bluetoothAdapter == null) {
            msgToast("Bluetooth não está acessível");
        } else {
            msgToast("Bluetooth está acessível");
        }
        // se o bluetooth está ativo
        try {
            if (bluetoothAdapter.isEnabled()) {
                msgToast("Bluetooth está ativo");
                imgBT.setImageResource(R.drawable.ic_blue_on);
                swBT.setChecked(true);
            } else {
                msgToast("Bluetooth está desativado");
                imgBT.setImageResource(R.drawable.ic_blue_off);
                swBT.setChecked(true);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        swBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(swBT.isChecked()) {
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intent, 0);
                } else if (!swBT.isChecked()) {
                    bluetoothAdapter.disable();
                    msgToast("Bluetooth desativado");
                    imgBT.setImageResource(R.drawable.ic_blue_off);
                    btnPareados.setEnabled(false);
                    btnConectar.setEnabled(false);
                }
            }
        });

        btnPareados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!bluetoothAdapter.isDiscovering()) {
                    Intent intent2 = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(intent2, 1);
                }
            }
        });

    }

    private void msgToast (String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case 0:
                if (resultCode == RESULT_OK) {
                    msgToast("Bluetooth ativado");
                    imgBT.setImageResource(R.drawable.ic_blue_on);
                    btnPareados.setEnabled(true);
                    btnConectar.setEnabled(true);
                } else {
                    msgToast("Bluetooth não ativado");
                    imgBT.setImageResource(R.drawable.ic_blue_off);
                }
                break;
            case 1:
                if(resultCode == 120) { // 120 é o código igual ao tempo de discovery
                    if (bluetoothAdapter.isEnabled()) {
                        dadosBT.clear();
                        dadosBT = new ArrayList<>();
                        Set<BluetoothDevice> BTdevices = bluetoothAdapter.getBondedDevices();
                        for (BluetoothDevice device : BTdevices) {
                            dadosBT.add(device.getName() + ", " + device.getAddress());
                        }
                        lstAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, dadosBT);
                        lstBT.setAdapter(lstAdapter);
                    } else {
                        msgToast("Bluetooth não está ativo");
                    }
                }
        }


        super.onActivityResult(requestCode, resultCode, data);
    }
}

package com.example.graficoeleicoes;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class PieChartActivity extends AppCompatActivity {

    private PieChart myPieChart;
    List<PieEntry> valores = new ArrayList<>();
    PieDataSet dataset1;
    PieData dados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pie_chart);

        myPieChart = findViewById(R.id.minhaPizza);

        /*Receber parâmetros da ActivityMain*/
        Bundle param = getIntent().getExtras();
        float v1, v2, v3;
        v1 = param.getFloat("V1");
        v2 = param.getFloat("V2");
        v3 = param.getFloat("V3");

        myPieChart.setUsePercentValues(true);
        myPieChart.setExtraOffsets(5,10,5,5);

        myPieChart.setDrawHoleEnabled(true);
        myPieChart.setHoleColor(Color.WHITE);
        myPieChart.setTransparentCircleRadius(31f);
        myPieChart.setHoleRadius(29f);

        /*Cor e fonte*/
        myPieChart.setEntryLabelColor(Color.DKGRAY);
        myPieChart.setEntryLabelTextSize(14f);


        valores.add(new PieEntry(v1, "Candidato 1"));
        valores.add(new PieEntry(v2, "Candidato 2"));
        valores.add(new PieEntry(v3, "Candidato 3"));

        /*Animação*/
        myPieChart.animateY(2000, Easing.EaseInOutCubic);

        dataset1 = new PieDataSet(valores, "Percentual de votos");
        dataset1.setColors(ColorTemplate.PASTEL_COLORS);
        dataset1.setSliceSpace(6f);
        dados = new PieData(dataset1);
        dados.setValueTextSize(14f);
        dados.setValueTextColor(Color.WHITE);

        myPieChart.setData(dados);

    }


}

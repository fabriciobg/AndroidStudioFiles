package imc.unp.com.qrcode;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class MainActivity extends AppCompatActivity {

    Button btnScanCode;
    TextView txtCode;
    ImageView imgQRCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Activity activity = this;

        btnScanCode = findViewById(R.id.btnScanCode);
        txtCode = findViewById(R.id.txtCodeLido);
        imgQRCode = findViewById(R.id.imgQRCode);

        btnScanCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator intentIntegrator = new IntentIntegrator(activity);
                intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
                intentIntegrator.setPrompt("Scam QR Code");
                intentIntegrator.setCameraId(0);
                intentIntegrator.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        IntentResult retorno = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(retorno != null) {
            if(retorno.getContents() != null){
                txtCode.setText(retorno.getContents());
                gerarQRCode();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void gerarQRCode(){
        String texto = txtCode.getText().toString();

        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();

        BitMatrix bitMatrix = null;

        try {
            bitMatrix = multiFormatWriter.encode(texto, BarcodeFormat.QR_CODE, 300, 300);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap image = barcodeEncoder.createBitmap(bitMatrix);
            imgQRCode.setImageBitmap(image);
        } catch (WriterException e) {
            e.printStackTrace();
        }

    }
}
